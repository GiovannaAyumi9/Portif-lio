create database consultorio

use consultorio
-- --------------------------------------------------------
-- Criando tabela medicos
-- --------------------------------------------------------
CREATE TABLE medicos (
    id INT NOT NULL,
    medico VARCHAR(80) NOT NULL,
    especialidade VARCHAR(30) NOT NULL,
    valor_consulta DECIMAL(7,2) NOT NULL,
    CONSTRAINT pk_medicos PRIMARY KEY (id)
);

-- --------------------------------------------------------
-- Criando tabela clientes
-- --------------------------------------------------------
CREATE TABLE clientes (
    id INT NOT NULL,
    nome VARCHAR(80) NOT NULL,
    dt_cadastro DATE NOT NULL,
    CONSTRAINT pk_clientes PRIMARY KEY (id)
);

-- --------------------------------------------------------
-- Criando tabela consulta
-- --------------------------------------------------------
CREATE TABLE consulta (
    id INT NOT NULL,
    medico_id INT NOT NULL,
    cliente_id INT NOT NULL,
    dia_hora DATETIME NOT NULL,
    pgto CHAR(1) NULL,
    CONSTRAINT pk_consulta PRIMARY KEY (id),
    CONSTRAINT fk_medico FOREIGN KEY (medico_id) REFERENCES medicos(id),
    CONSTRAINT fk_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

-- --------------------------------------------------------
-- Populando tabela medicos
-- --------------------------------------------------------
INSERT INTO medicos (id, medico, especialidade, valor_consulta) 
VALUES (1, 'Gaspar da Silva', 'cirurgia plástica', 500.00);

INSERT INTO medicos (id, medico, especialidade, valor_consulta) 
VALUES (2, 'José Alencar', 'ortopedia', 300.00);

INSERT INTO medicos (id, medico, especialidade, valor_consulta) 
VALUES (3, 'Aline Santiago', 'gastrologia', 300.00);

INSERT INTO medicos (id, medico, especialidade, valor_consulta) 
VALUES (4, 'Penélope Félix', 'dermatologista', 400.00);

INSERT INTO medicos (id, medico, especialidade, valor_consulta) 
VALUES (5, 'Matusalem Borges', 'geriatria', 300.00);

-- --------------------------------------------------------
-- Populando tabela clientes
-- --------------------------------------------------------
INSERT INTO clientes (id, nome, dt_cadastro) 
VALUES (1, 'José da Silva', '2023-03-13');

INSERT INTO clientes (id, nome, dt_cadastro) 
VALUES (2, 'Mariana Teles', '2020-04-02');

INSERT INTO clientes (id, nome, dt_cadastro) 
VALUES (3, 'Rosangela Guedes', '2020-05-01');

INSERT INTO clientes (id, nome, dt_cadastro) 
VALUES (4, 'Aline Santos', '2015-07-03');

INSERT INTO clientes (id, nome, dt_cadastro) 
VALUES (5, 'João Santos de Souza', '2019-03-04');

-- --------------------------------------------------------
-- Populando tabela consulta
-- --------------------------------------------------------
INSERT INTO consulta (id, medico_id, cliente_id, dia_hora, pgto) 
VALUES (1, 1, 2, '2023-04-12 14:15:00', 'S');

INSERT INTO consulta (id, medico_id, cliente_id, dia_hora, pgto) 
VALUES (2, 3, 1, '2023-03-13 10:00:00', 'S');

INSERT INTO consulta (id, medico_id, cliente_id, dia_hora, pgto) 
VALUES (3, 3, 4, '2023-03-13 12:00:00', 'S');

INSERT INTO consulta (id, medico_id, cliente_id, dia_hora, pgto) 
VALUES (4, 2, 5, '2023-04-20 11:00:00', NULL);

INSERT INTO consulta (id, medico_id, cliente_id, dia_hora, pgto) 
VALUES (5, 4, 4, '2023-04-01 07:00:00', 'S');