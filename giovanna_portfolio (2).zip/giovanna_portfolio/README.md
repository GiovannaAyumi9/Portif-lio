# Portfólio — Giovanna Ayumi Iamamoto

Site pessoal responsivo feito com HTML, CSS e JavaScript, pronto para publicação no GitHub Pages.

## Personalizações antes de publicar

- Troque os links genéricos do GitHub, LinkedIn e Figma pelos seus links reais.
- Atualize o e-mail `seuemail@exemplo.com`.
- Nos cards de projetos, coloque apenas trabalhos que você realmente realizou e links que estejam funcionando.
- Se desejar, acrescente o nome da faculdade e detalhes dos projetos acadêmicos.

## Como visualizar

Abra `index.html` diretamente no navegador. O CSS e o JavaScript estão no próprio arquivo, então ele funciona sem dependências extras.

## Como publicar no GitHub Pages

1. Crie um repositório público no GitHub, por exemplo `portfolio`.
2. Envie `index.html` e `README.md` para a raiz do repositório.
3. Vá em **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/(root)` e salve.
6. Aguarde o GitHub Pages publicar o site.

Documentação oficial: https://docs.github.com/en/pages

## Tecnologias

- HTML5
- CSS3 responsivo
- JavaScript


## Projetos apresentados
- `projetos/consultorio.sql`: script SQL para banco de dados de consultório.
- `projetos/hotel-sereno.zip`: arquivos enviados do projeto de site Hotel Sereno.
